# Fairyland Cake Co. Website (WEDE5020 Part 3)

Student: Itumeleng Joan Ndlovu (ST10515918) | Module: Web Development (Introduction), WEDE5020

Multi-page website for Fairyland Cake Co., a Johannesburg artisan bakery. Built with HTML5, CSS3 and vanilla JavaScript. Visual style follows the Château Gateaux cakes page (crimson header bar, hanging logo tab, hero banner, round category tiles, four-column product grid) while keeping the proposal's pastel pink, cream and charcoal palette and Playfair Display / Open Sans fonts.

## Pages and structure
`index.html` home | `menu.html` cakes and pricing | `gallery.html` | `about.html` | `enquiry.html` | `contact.html`
`css/style.css` | `js/data.js` (products and gallery data) | `js/main.js` (all behaviour) | `images/` | `robots.txt` | `sitemap.xml` | `_headers`

## Part 3 requirements and where they are
| Requirement | Implementation |
|---|---|
| Interactive elements | Tabs (home "Our journey"), accordions (FAQs, About), modal (cake details on menu and home) |
| Interactive map | Leaflet + OpenStreetMap on `contact.html`: pickup and market markers, popups, fly-to buttons, directions links |
| Animations / DOM manipulation | Hero entrance, tab/modal transitions, animated accordion, sticky header shadow, back-to-top button created in JS, live price estimate, character counter |
| Gallery lightbox | `gallery.html`: category filter, click to enlarge, previous/next, arrow keys, Esc, captions |
| Dynamic content + search | `menu.html`: 24 cakes rendered from `data.js`, live search, category tiles, sort by name/price, result count |
| Enquiry form | `enquiry.html`: text, email, tel, date, selects, checkboxes, radios, textarea |
| Validation | Inline messages on blur/input, ARIA invalid states, error summary, focus on first error (name, email, SA phone, date, details, consent) |
| Enquiry response | Estimate in rand (size, flavour, dietary, delivery, rush fee), date availability check, reference number, email button |
| Contact email | `contact.html`: validated form compiles an email preview and opens it to the recipient set in `CFG.email` (`js/main.js`) |
| SEO | Unique title, description and keywords per page, one H1 with H2/H3 structure, canonical and Open Graph tags, descriptive image file names and alt text, clean URLs, internal links, mobile-friendly layout, Bakery JSON-LD, `robots.txt`, `sitemap.xml`, lazy-loaded images, deferred scripts, security headers in `_headers` |
| Off-page SEO plan | Footer social links, local business schema, list the business on Google Business Profile and local directories, ask customers to link and tag |

## Setup notes
- Change `CFG.email`, map pins and `CFG.booked` dates at the top of `js/main.js`. Pins are demo locations in Johannesburg.
- Replace social links in the footer and the domain `https://fairylandcakeco.netlify.app/` (in every page's canonical tags, `sitemap.xml`, `robots.txt`) once your live URL is known.

## Deployment (no GitHub needed)
Go to Netlify, choose "Add new site", then "Deploy manually", and drag in the project folder. Rename the site and update the domain as above. Netlify reads `_headers` automatically.

## Changelog
### 3.0.0 (14 October 2026) Part 3
Add real lecturer feedback from Part 2 in the table below before submitting.

| Part 2 feedback | Change made |
|---|---|
| (paste feedback point 1) | |
| (paste feedback point 2) | |

Development record:
- Restyled all pages to match the Château Gateaux cakes layout: crimson sticky header, hanging logo tab, photo hero banner, circular category tiles, product grid.
- Replaced placeholder content with 24 products (prices in rand) and real cake photos, renamed descriptively (for example `blush-pink-two-tier-wedding-cake-with-peonies.jpg`) with alt text.
- Added tabs, accordions and a modal; added Leaflet map; added lightbox gallery with filters; added search, filter and sort.
- Built enquiry form with validation, estimate and availability response; built contact form that compiles an email.
- Added SEO tags, JSON-LD, `robots.txt`, `sitemap.xml`; added `_headers` security policy.
- Accessibility: skip link, visible focus, keyboard support for modal and lightbox, reduced-motion support.

### 2.0.0 Part 2: HTML/CSS structure, navigation, responsive layout. 
### 1.0.0 Part 1: Business proposal, sitemap and wireframes.

## References
Ndlovu, I. 2026. *Fairyland Cake Co. business proposal*. Unpublished student document. 14 August.
Château Gateaux. n.d. *Cakes*. Available at: https://chateaugateaux.co.za [Accessed 14 October 2026]. (layout inspiration only)
Leaflet. 2023. *Leaflet 1.9.4*. Available at: https://leafletjs.com [Accessed 14 October 2026].
OpenStreetMap contributors. n.d. *OpenStreetMap*. Available at: https://www.openstreetmap.org [Accessed 14 October 2026].
Google. n.d. *Google Fonts: Playfair Display and Open Sans*. Available at: https://fonts.google.com [Accessed 14 October 2026].
Pinterest. n.d. *Cake images (wedding, baby shower, birthday, cupcakes)*. Available at: https://www.pinterest.com [Accessed 12 August 2026]. (add the exact pin links from your Part 1 reference list)
Lemon8 / @jenn.andrade. n.d. *Vintage heart cakes*. [Accessed 12 August 2026].
