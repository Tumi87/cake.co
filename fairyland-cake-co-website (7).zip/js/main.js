'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)],R=n=>'R'+n.toLocaleString('en-ZA');
const CFG={email:'info@fairylandcakeco.co.za',pins:[['Cake pickup point (demo address)',-26.1467,28.0436],['Weekend market stall (demo location)',-26.0605,28.0196]],booked:['2026-11-14','2026-11-28','2026-12-12','2026-12-19','2026-12-24']};
const cake=(t,a,b)=>`<svg viewBox="0 0 200 170" role="img" aria-label="Illustration of a ${t} cake"><ellipse cx="100" cy="150" rx="86" ry="10" fill="#0002"/><ellipse cx="100" cy="144" rx="84" ry="12" fill="#fff"/>`+({
layer:`<rect x="40" y="82" width="120" height="58" rx="6" fill="${a}"/><rect x="40" y="106" width="120" height="8" fill="#fff9"/><ellipse cx="100" cy="82" rx="60" ry="14" fill="${b}"/><circle cx="80" cy="76" r="6" fill="#c8003c"/><circle cx="104" cy="72" r="6" fill="#c8003c"/><circle cx="124" cy="78" r="6" fill="#c8003c"/>`,
tier:`<rect x="30" y="98" width="140" height="42" rx="5" fill="${a}"/><ellipse cx="100" cy="98" rx="70" ry="12" fill="${b}"/><rect x="58" y="62" width="84" height="38" rx="5" fill="${a}"/><ellipse cx="100" cy="62" rx="42" ry="9" fill="${b}"/><circle cx="100" cy="52" r="9" fill="#c8003c"/><circle cx="84" cy="94" r="5" fill="#f4c2c2"/><circle cx="116" cy="94" r="5" fill="#f4c2c2"/>`,
cupcake:`<path d="M62 100h76l-12 42H74z" fill="${a}"/><circle cx="100" cy="88" r="34" fill="${b}"/><circle cx="100" cy="66" r="22" fill="${b}"/><circle cx="100" cy="46" r="10" fill="#c8003c"/>`,
tub:`<rect x="46" y="70" width="108" height="72" rx="14" fill="#fff" stroke="#bbb" stroke-width="3"/><rect x="52" y="76" width="96" height="22" fill="${b}"/><rect x="52" y="98" width="96" height="22" fill="${a}"/><rect x="52" y="120" width="96" height="16" fill="${b}"/>`,
cheese:`<rect x="34" y="96" width="132" height="44" rx="6" fill="#e9c98f"/><rect x="34" y="96" width="132" height="30" fill="${a}"/><ellipse cx="100" cy="96" rx="66" ry="14" fill="${b}"/><circle cx="84" cy="92" r="5" fill="#fff"/><circle cx="112" cy="90" r="5" fill="#fff"/>`}[t])+'</svg>';
const CATS={birthday:['🎂','Birthday Cakes'],wedding:['💍','Wedding Cakes'],'baby-shower':['🍼','Baby Showers'],minis:['🧁','Cupcakes & Minis'],cheesecakes:['🍰','Cheesecakes'],tubs:['🥄','Dessert Tubs']};
const card=p=>`<button class="card" data-id="${p.id}"><div class="im">${p.img?`<img src="images/${p.img}" alt="${p.alt}" loading="lazy" width="${p.w}" height="${p.h}">`:cake(p.t,p.a,p.b)}</div><h3>${p.name}</h3><p>${p.desc}</p><p><small>From ${R(p.price)}</small></p></button>`;
/* modal */
let last;const md=$('#md');
function openMd(html){last=document.activeElement;$('#mb').innerHTML=html;md.classList.add('o');$('.x',md).focus()}
function closeMd(){md.classList.remove('o');last&&last.focus()}
if(md){md.addEventListener('click',e=>{if(e.target===md||e.target.classList.contains('x'))closeMd()});}
function bindCards(root){root.addEventListener('click',e=>{const c=e.target.closest('.card');if(!c)return;const p=P.find(x=>x.id===c.dataset.id);
openMd(`<div class="two"><div class="im card" style="pointer-events:none">${p.img?`<img src="images/${p.img}" alt="${p.alt}">`:cake(p.t,p.a,p.b)}</div><div><h2>${p.name}</h2><p>${p.desc}</p><p><strong>From ${R(p.price)}</strong> &middot; serves about ${p.serves}</p><p>Dietary options (eggless, gluten-free, vegan) available on request.</p><a class="btn" href="enquiry.html?cake=${p.id}">Enquire about this cake</a></div></div>`)})}
/* menu / featured */
const grid=$('#grid');
if(grid){const st={cat:new URLSearchParams(location.search).get('cat')||'',q:'',s:'name'};
const draw=()=>{let l=P.filter(p=>(!st.cat||p.cat===st.cat)&&(p.name+' '+p.desc+' '+p.cat).toLowerCase().includes(st.q));
l.sort((a,b)=>st.s==='name'?a.name.localeCompare(b.name):st.s==='lo'?a.price-b.price:b.price-a.price);
grid.innerHTML=l.map(card).join('')||'<p>No cakes match your search. Try another word or clear the filter.</p>';$('#cnt').textContent=l.length+' cake'+(l.length==1?'':'s')+' shown';
$$('.cats button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.c===st.cat))};
$('.cats').innerHTML=Object.entries(CATS).map(([k,v])=>`<button data-c="${k}" aria-pressed="false"><span class="ic" aria-hidden="true">${v[0]}</span>${v[1]}</button>`).join('');
$('.cats').addEventListener('click',e=>{const b=e.target.closest('button');if(b){st.cat=st.cat===b.dataset.c?'':b.dataset.c;draw()}});
$('#q').addEventListener('input',e=>{st.q=e.target.value.trim().toLowerCase();draw()});$('#so').addEventListener('change',e=>{st.s=e.target.value;draw()});draw();bindCards(grid)}
const feat=$('#feat');if(feat){feat.innerHTML=['birthday-fairy-butterfly','wedding-rose-drip','baby-pram-three-tier','minis-rose-cupcakes'].map(id=>card(P.find(p=>p.id===id))).join('');bindCards(feat)}
/* tabs + accordion */
$$('[role=tablist]').forEach(tl=>tl.addEventListener('click',e=>{const t=e.target.closest('[role=tab]');if(!t)return;$$('[role=tab]',tl).forEach(x=>{const on=x===t;x.setAttribute('aria-selected',on);$('#'+x.getAttribute('aria-controls')).hidden=!on})}));
$$('.acc button').forEach(b=>b.addEventListener('click',()=>{const o=b.getAttribute('aria-expanded')!=='true';b.setAttribute('aria-expanded',o);b.nextElementSibling.classList.toggle('o',o)}));
/* gallery + lightbox */

const gal=$('#gal');if(gal){let cur='',vis=[],ix=0;const lb=$('#lb');
const show=()=>{vis=G.filter(g=>!cur||g[2]===cur);gal.innerHTML=vis.map((g,i)=>`<button data-i="${i}" aria-label="Open photo: ${g[1]}"><img src="images/${g[0]}" alt="${g[1]}" width="${g[3]}" height="${g[4]}" loading="lazy"></button>`).join('')};
$('#gf').innerHTML=['',...new Set(G.map(g=>g[2]))].map(c=>`<button role="tab" aria-selected="${c===''}" data-c="${c}">${c||'All photos'}</button>`).join('');
$('#gf').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;cur=b.dataset.c;$$('#gf button').forEach(x=>x.setAttribute('aria-selected',x===b));show()});
const go=n=>{ix=(n+vis.length)%vis.length;const g=vis[ix];$('#li').src='images/'+g[0];$('#li').alt=g[1];$('#lc').textContent=g[1]+` (${ix+1} of ${vis.length})`};
gal.addEventListener('click',e=>{const b=e.target.closest('button');if(b){last=b;go(+b.dataset.i);lb.classList.add('o');$('.x',lb).focus()}});
const cl=()=>{lb.classList.remove('o');last&&last.focus()};lb.addEventListener('click',e=>{if(e.target===lb||e.target.classList.contains('x'))cl();if(e.target.id==='pv')go(ix-1);if(e.target.id==='nx')go(ix+1)});
document.addEventListener('keydown',e=>{if(!lb.classList.contains('o'))return;if(e.key==='Escape')cl();if(e.key==='ArrowLeft')go(ix-1);if(e.key==='ArrowRight')go(ix+1)});show()}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&md&&md.classList.contains('o'))closeMd()});
/* forms */
const V={name:v=>/^[A-Za-zÀ-ÿ' -]{2,60}$/.test(v)||'Enter your full name (letters only, at least 2 characters).',email:v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)||'Enter a valid email address, e.g. name@example.com.',
phone:v=>/^(\+27|0)[1-9]\d{8}$/.test(v.replace(/[\s-]/g,''))||'Enter a valid South African number, e.g. 082 123 4567.',phoneOpt:v=>!v||V.phone(v),req:v=>!!v||'Please choose an option.',
date:v=>{if(!v)return'Please choose your event date.';return new Date(v)>=new Date(new Date().toDateString())||'Event date cannot be in the past.'},
notes:v=>v.length>=10||'Please tell us a little more (at least 10 characters).',msg:v=>v.length>=15||'Your message must be at least 15 characters.',chk:v=>v||'Please tick the box to continue.'};
function check(f,el){const k=el.dataset.v;if(!k)return true;const v=el.type==='checkbox'?el.checked:el.value.trim();const r=V[k](v),ok=r===true;el.setAttribute('aria-invalid',!ok);
const e=$('#e-'+el.id);if(e)e.textContent=ok?'':r;return ok}
function wire(f,done){$$('[data-v]',f).forEach(el=>{el.addEventListener('blur',()=>check(f,el));el.addEventListener('input',()=>el.getAttribute('aria-invalid')&&check(f,el))});
f.addEventListener('submit',e=>{e.preventDefault();const bad=$$('[data-v]',f).filter(el=>!check(f,el));if(bad.length){bad[0].focus();$('#sum').textContent='Please fix '+bad.length+' field'+(bad.length>1?'s':'')+' before sending.';return}$('#sum').textContent='';done(Object.fromEntries(new FormData(f)))})}
const SZ={mini:['Mini (serves 4)',280,3],s:['Small 6-inch (serves 10)',480,3],m:['Medium 8-inch (serves 16)',650,3],l:['Large 10-inch (serves 24)',850,5],t2:['Two-tier (serves 40)',2400,21],t3:['Three-tier (serves 70)',4200,28]},FL={Vanilla:0,Chocolate:0,'Red velvet':60,Lemon:30,'Salted caramel':50,'Berry':60},DT={Eggless:60,'Gluten-free':120,Vegan:150,'Nut-free':0};
const ef=$('#ef');
if(ef){$('#size').innerHTML='<option value="">Choose size</option>'+Object.entries(SZ).map(([k,v])=>`<option value="${k}">${v[0]} – from ${R(v[1])}</option>`).join('');$('#flav').innerHTML='<option value="">Choose flavour</option>'+Object.keys(FL).map(k=>`<option>${k}</option>`).join('');
$('#dt').innerHTML=Object.keys(DT).map(k=>`<label class="ch"><input type="checkbox" name="diet" value="${k}"> ${k}</label>`).join('');
$('#date').min=new Date().toISOString().slice(0,10);const pre=P.find(p=>p.id===new URLSearchParams(location.search).get('cake'));if(pre){$('#notes').value='I am interested in the '+pre.name+'. ';}
const quote=d=>{const s=SZ[d.size];if(!s)return null;let t=s[1]+(FL[d.flav]||0)+$$('[name=diet]:checked',ef).reduce((a,c)=>a+DT[c.value],0)+(d.method==='delivery'?120:0);return{t,s}};
const live=()=>{const q=quote(Object.fromEntries(new FormData(ef)));$('#live').textContent=q?'Estimated from '+R(q.t):'Choose a size to see an estimate.'};ef.addEventListener('change',live);live();
wire(ef,d=>{const q=quote(d),when=new Date(d.date),days=Math.ceil((when-new Date(new Date().toDateString()))/864e5),iso=d.date;let av,cls='ok',total=q.t;
if(CFG.booked.includes(iso)){av='Sorry, that date is fully booked. Please try the day before or after.';cls='no'}else if(when.getDay()===1){av='We are closed on Mondays. Choose another day for collection or delivery.';cls='no'}
else if(days<q.s[2]){av=`Not available: this cake needs ${q.s[2]} days notice.`;cls='no'}else if(days<q.s[2]+4){total=Math.round(total*1.25);av='Available as a rush order (+25% rush fee).'}else av='Available on '+when.toDateString()+'.';
const rf='FCC-'+Date.now().toString(36).toUpperCase().slice(-6),out=$('#out');out.hidden=false;out.innerHTML='<h2>Thank you, <span id="rn"></span></h2><dl><dt>Estimate</dt><dd id="rp"></dd><dt>Availability</dt><dd id="ra"></dd><dt>Reference</dt><dd id="rr"></dd></dl><p>This is an estimate. Our baker confirms your final quote within 24 hours.</p><a class="btn" id="rm">Email this enquiry</a>';
$('#rn').textContent=d.name.split(' ')[0];$('#rp').textContent=q.s[0]+': '+R(total)+(d.method==='delivery'?' incl. delivery':'');$('#ra').textContent=av;$('#ra').className=cls;$('#rr').textContent=rf;
$('#rm').href='mailto:'+CFG.email+'?subject='+encodeURIComponent('Cake enquiry '+rf)+'&body='+encodeURIComponent(`Name: ${d.name}\nEmail: ${d.email}\nPhone: ${d.phone}\nType: ${d.type}\nSize: ${q.s[0]}\nFlavour: ${d.flav}\nDietary: ${$$('[name=diet]:checked',ef).map(c=>c.value).join(', ')||'None'}\nDate: ${d.date}\n${d.method}\nEstimate: ${R(total)}\n\nDesign details:\n${d.notes}`);out.scrollIntoView({behavior:'smooth'});out.focus()})}
const cf=$('#cf');
if(cf){const m=$('#message');m.addEventListener('input',()=>$('#cc').textContent=m.value.length+'/1000');
wire(cf,d=>{const body=`Hello Fairyland Cake Co.,\n\n${d.message}\n\nKind regards,\n${d.name}\n${d.email}${d.phone?'\n'+d.phone:''}`,sub=`[${d.topic}] ${d.subject}`,out=$('#out');out.hidden=false;
$('#pv').textContent=`To: ${CFG.email}\nSubject: ${sub}\n\n${body}`;$('#send').href='mailto:'+CFG.email+'?subject='+encodeURIComponent(sub)+'&body='+encodeURIComponent(body);out.scrollIntoView({behavior:'smooth'})})}
/* map */
const mp=$('#map');if(mp){if(window.L){const m=L.map(mp).setView([CFG.pins[0][1],CFG.pins[0][2]],11);L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'}).addTo(m);
const ms=CFG.pins.map(p=>L.marker([p[1],p[2]]).addTo(m).bindPopup('<b>'+p[0]+'</b><br><a target="_blank" rel="noopener noreferrer" href="https://www.openstreetmap.org/directions?to='+p[1]+','+p[2]+'">Get directions</a>'));
$$('[data-pin]').forEach(b=>b.addEventListener('click',()=>{const i=+b.dataset.pin;m.flyTo([CFG.pins[i][1],CFG.pins[i][2]],15);ms[i].openPopup()}))}else mp.innerHTML='<p style="padding:20px">The map could not load. <a href="https://www.openstreetmap.org/#map=12/-26.1467/28.0436">Open it on OpenStreetMap</a>.</p>'}
/* chrome */
const hd=$('header');addEventListener('scroll',()=>{hd.classList.toggle('sc',scrollY>10);tp.hidden=scrollY<500});
const tp=document.createElement('button');tp.id='top';tp.hidden=true;tp.textContent='↑';tp.setAttribute('aria-label','Back to top');tp.onclick=()=>scrollTo({top:0});document.body.append(tp);
$('#mt').addEventListener('click',e=>{const o=$('nav').classList.toggle('o');e.target.setAttribute('aria-expanded',o)});
